﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication2.Models          //filename and model name
{
    public class StudentModel
    {
        public int roll { get; set; }
        public string name { get; set; }
        public int age { get; set; }

    }
}