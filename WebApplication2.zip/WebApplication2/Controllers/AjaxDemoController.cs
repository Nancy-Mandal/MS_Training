﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebApplication2.Models;

namespace WebApplication2.Controllers
{
    
    public class AjaxDemoController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }
        // GET: AjaxDemo
        [HttpPost]
        public ActionResult GetStudentList()
        {
            List<StudentModel> lstStudentModel = new List<StudentModel>();

            lstStudentModel.Add(new StudentModel { roll = 1, name = "Nancy", age = 21 });
            lstStudentModel.Add(new StudentModel { roll = 2, name = "Aditi", age = 20 });
            lstStudentModel.Add(new StudentModel { roll = 3, name = "Suman", age = 22 });

            return Json(lstStudentModel);

        }
    }
}